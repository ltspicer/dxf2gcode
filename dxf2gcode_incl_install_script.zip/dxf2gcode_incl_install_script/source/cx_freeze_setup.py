#!/usr/bin/python3
# To create MSI installer with automatic Menu shortcut installation run the following:
# python3 cx_freeze_setup.py bdist_msi

import os
import shutil
import sys
import glob

from cx_Freeze import Executable, setup


version = "20260522"

base = 'Console'
if sys.platform == 'win32':
    # Use 'gui' instead of 'Win32GUI' for compatibility with newer cx_Freeze versions
    base = 'gui'


# script based on
# https://github.com/Fireforge/PySide-OpenGL-cx_Freeze-Example
# http://stackoverflow.com/questions/15486292/cx-freeze-doesnt-find-all-dependencies
def include_OpenGL():
    import site
    
    # Get the site-packages directory
    site_packages = site.getsitepackages()[0]
    path_base = os.path.join(site_packages, "OpenGL")
    
    if not os.path.isdir(path_base):
        print("[WARNING] OpenGL directory not found at: %s" % path_base)
        print("[WARNING] cx_Freeze may have issues including OpenGL")
        return []
    
    skip_count = len(path_base)
    zip_includes = [(path_base, "OpenGL")]
    for root, sub_folders, files in os.walk(path_base):
        for file_in_root in files:
            zip_includes.append(
                ("{}".format(os.path.join(root, file_in_root)),
                 "{}".format(os.path.join("OpenGL", root[skip_count + 1:], file_in_root))
                 )
            )
    return zip_includes


# Remove the existing folders
shutil.rmtree("build", ignore_errors=True)
shutil.rmtree("dist", ignore_errors=True)


# Collect translation files if they exist (graceful fallback if not built)
includefiles = ['COPYING', 'README.txt']

# Try to include translation files if they exist
i18n_files = [
    (r'i18n\dxf2gcode_de.qm', r'i18n\dxf2gcode_de.qm'),
    (r'i18n\dxf2gcode_fr.qm', r'i18n\dxf2gcode_fr.qm'),
    (r'i18n\dxf2gcode_ru.qm', r'i18n\dxf2gcode_ru.qm')
]

for src, dst in i18n_files:
    if os.path.isfile(src):
        includefiles.append((src, dst))
    else:
        print("[WARNING] Translation file not found: %s (continuing without it)" % src)

# Also try to include .ts source files as fallback
for ts_file in ['i18n/dxf2gcode_de.ts', 'i18n/dxf2gcode_fr.ts', 'i18n/dxf2gcode_ru.ts']:
    if os.path.isfile(ts_file):
        # Just include the directory for now
        break
includes = []
excludes = []



options = {
    'build_exe': {
        # 'packages': '' ,
        'includes':includes,
        'excludes':excludes,
        'include_files':includefiles,
        'zip_includes': include_OpenGL(),
        'silent': True
    }
}



executables = [
    Executable(script='dxf2gcode.py',
               base=base,
               icon=r"images\DXF2GCODE-001.ico",
               target_name="dxf2gcode.exe",
               shortcut_name="DXF to G-Code Converter",
               shortcut_dir="ProgramMenuFolder"
               )
]

#If you want to run the script directly uncomment the following.
#sys.argv.append("bdist_msi")


setup(name='DXF2GCODE',
      version=version[0:4] + "." + version[4:6] + "." + version[6:8],  # converts YYYYMMDD -> YYYY.MM.DD
      description='Converting 2D drawings to CNC machine compatible G-Code. Release Candidate 2 based on development branch',
      options=options,
      executables=executables
      )

# Move MSI file from dist/ to script directory
msi_files = glob.glob("dist/*.msi")
if msi_files:
    for msi_file in msi_files:
        msi_name = os.path.basename(msi_file)
        destination = os.path.join(os.path.dirname(__file__), msi_name)
        shutil.move(msi_file, destination)
        print(f"[INFO] MSI moved to: {destination}")
    
    # Remove now-empty dist and build folders
    shutil.rmtree("dist", ignore_errors=True)
    shutil.rmtree("build", ignore_errors=True)

@echo off
REM ################################################################################
REM #
REM # DXF2GCODE Installation Script for Windows V1.0
REM #
REM # This script creates a virtual environment, installs dependencies (including
REM # cx_Freeze), and builds a standalone Windows .exe installer
REM # 
REM # Usage: install.bat
REM #
REM # by Daniel Luginbühl 2026
REM #
REM ################################################################################

setlocal enabledelayedexpansion

REM Configuration
set VENV_DIR=%USERPROFILE%\.venv\dxf2gcode
set SCRIPT_DIR=%~dp0
set TARGET_DIR=%USERPROFILE%\dxf2gcode
set PYTHON_REQUIRED=3.10

echo.
echo ==================================
echo DXF2GCODE Installation for Windows
echo ==================================
echo.

REM Developer Mode Prompt
set /p DEVELOPER="Are you developer? (y/N): "
if /i "%DEVELOPER%"=="" set DEVELOPER=n
if /i not "%DEVELOPER%"=="y" goto skip_build
echo.

REM Step 1: Check Python version
echo Step 1: Checking Python version...
python --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo [ERROR] Python is not installed or not in PATH
    echo Please install Python 3.10 or later from https://www.python.org/
    echo Make sure to check "Add Python to PATH" during installation
    echo.
    pause
    exit /b 1
)

for /f "tokens=2" %%i in ('python --version 2^>^&1') do set PYTHON_VERSION=%%i
echo [OK] Python %PYTHON_VERSION% found
echo.

REM Step 2: Create virtual environment
echo Step 2: Creating virtual environment at %VENV_DIR%...
if exist "%VENV_DIR%" (
    echo Virtual environment already exists. Removing old one...
    rmdir /s /q "%VENV_DIR%" >nul 2>&1
)

python -m venv "%VENV_DIR%"
if errorlevel 1 (
    echo [ERROR] Failed to create virtual environment
    pause
    exit /b 1
)
echo [OK] Virtual environment created
echo.

REM Step 3: Upgrade pip, setuptools, wheel
echo Step 3: Upgrading pip, setuptools, wheel...
"%VENV_DIR%\Scripts\python" -m pip install --upgrade pip setuptools wheel -q
if errorlevel 1 (
    echo [ERROR] Failed to upgrade pip
    pause
    exit /b 1
)
echo [OK] Pip upgraded
echo.

REM Step 4: Install cx_Freeze for building Windows executable
echo Step 4: Installing cx_Freeze for building Windows executable...
"%VENV_DIR%\Scripts\pip" install cx_Freeze -q
if errorlevel 1 (
    echo [ERROR] Failed to install cx_Freeze
    pause
    exit /b 1
)
echo [OK] cx_Freeze installed
echo.

REM Step 5: Install dxf2gcode and other dependencies
echo Step 5: Installing dxf2gcode dependencies...
cd /d "%SCRIPT_DIR%"
"%VENV_DIR%\Scripts\pip" install . -q
if errorlevel 1 (
    echo [ERROR] Failed to install dxf2gcode
    pause
    exit /b 1
)
echo [OK] dxf2gcode and dependencies installed
echo.

REM Step 6: Generate UI and translation files (equivalent to "make prepare")
echo Step 6: Generating UI files and translations...
"%VENV_DIR%\Scripts\python" make_py_uic.py
if errorlevel 1 (
    echo [ERROR] Failed to generate UI files
    pause
    exit /b 1
)

"%VENV_DIR%\Scripts\python" make_tr.py --no-pylupdate
if errorlevel 1 (
    echo [WARNING] Failed to generate translation files
    echo [INFO] Continuing - translations are optional
)
echo [OK] UI files generated (translations optional)
echo.

REM Step 7: Build the Windows executable
echo Step 7: Building Windows executable with cx_Freeze...
"%VENV_DIR%\Scripts\python" cx_freeze_setup.py bdist_msi
if errorlevel 1 (
    echo [ERROR] Failed to build executable
    echo This might be due to missing build tools or dependency issues.
    pause
    exit /b 1
)
echo [OK] Build complete
echo.

:skip_build
REM Step 8: Find and execute the installer
for /f "tokens=*" %%F in ('dir /b "%SCRIPT_DIR%*.msi" 2^>nul') do set INSTALLER=%%F

if defined INSTALLER (
    echo ================================
    echo Build Successful!
    echo ================================
    echo.
    echo The Windows installer has been created:
    echo %SCRIPT_DIR%%INSTALLER%
    echo.
    echo Starting installation wizard...
    echo.
    
    REM Execute the MSI installer
    start "" msiexec /i "%SCRIPT_DIR%%INSTALLER%"
    
    echo.
    echo The installer window should open now.
    echo The installer will add DXF2GCODE to your Start Menu and Programs.
    echo.
) else (
    echo [WARNING] Installer not found in expected location
    echo Please check the current directory for the .msi file
    exit /b 1
)

echo ================================
echo Cleanup ^& Further Information
echo ================================
echo.
echo After successful installation, you can remove the directories:
echo   - Virtual environment: rmdir /s "%VENV_DIR%"
for %%i in ("%SCRIPT_DIR%\..") do echo   - Source dir: rmdir /s "%%~fi"
echo.
echo DXF2GCODE will be accessible from your Start Menu.
echo.

pause
echo Done!


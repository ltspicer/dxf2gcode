#!/usr/bin/env python3

"""
Generates the python file based on the defined uifile
"""

import os
import subprocess
import sys
import tempfile


def which(program):
    def is_exe(fpath):
        return os.path.isfile(fpath) and os.access(fpath, os.X_OK)

    fpath, fname = os.path.split(program)
    if fpath:
        if is_exe(program):
            return program
    else:
        for path in os.environ["PATH"].split(os.pathsep):
            exe_file = os.path.join(path, program)
            if is_exe(exe_file):
                return exe_file

    return None


pyQtVer = '5'

if "linux" in sys.platform.lower() or "unix" in sys.platform.lower() or "darwin" in sys.platform.lower():
    # On Linux and macOS executables are normaly on the PATH (on Linux please install packages like lib64-qt5-devel and python-qt5-devel)
    names = ["pyuic%s" % pyQtVer]
    UICPATH = None

    for name in names:
        if which(name):
            UICPATH = name
            break

    if not UICPATH:
        print("ERROR: Cannot file uic tool.")
        print("Please consider to install uic tool - to use this script.")
        sys.exit(1)

    names = ["pyrcc%s" % pyQtVer]
    RCCPATH = None

    for name in names:
        if which(name):
            RCCPATH = name
            break

    if not UICPATH:
        print("ERROR: Cannot file rcc tool.")
        print("Please consider to install rcc tool - to use this script.")
        sys.exit(1)

    RCCPATH = "pyrcc%s" % pyQtVer

    print("Using platform tools \"%s\" and \"%s\"\n" % (UICPATH, RCCPATH))
else:
    # Windows: Look for pyuic5 and pyrcc5 in venv or system Python
    import site
    
    UICPATH = None
    RCCPATH = None
    
    # First, try to find them in standard venv locations
    for potential_path in site.getsitepackages():
        # In a venv, they're in ../Scripts/ relative to site-packages
        venv_scripts = os.path.normpath(os.path.join(potential_path, "..", "..", "Scripts"))
        
        test_uic = os.path.join(venv_scripts, "pyuic5.exe")
        test_rcc = os.path.join(venv_scripts, "pyrcc5.exe")
        
        if os.path.isfile(test_uic):
            UICPATH = test_uic
        if os.path.isfile(test_rcc):
            RCCPATH = test_rcc
        
        if UICPATH and RCCPATH:
            break
    
    # Fallback: try direct site-packages installation (system Python)
    if not UICPATH or not RCCPATH:
        for potential_path in site.getsitepackages():
            test_uic = os.path.join(potential_path, "pyuic5.exe")
            test_rcc = os.path.join(potential_path, "pyrcc5.exe")
            
            if os.path.isfile(test_uic) and not UICPATH:
                UICPATH = test_uic
            if os.path.isfile(test_rcc) and not RCCPATH:
                RCCPATH = test_rcc
    
    if not UICPATH:
        print("ERROR: Cannot find pyuic5.exe")
        print("Please ensure PyQt5 is installed: pip install PyQt5")
        sys.exit(1)
    
    if not RCCPATH:
        print("ERROR: Cannot find pyrcc5.exe")
        print("Please ensure PyQt5 is installed: pip install PyQt5")
        sys.exit(1)
    
    print("Using Windows platform tools \"%s\" and \"%s\"\n" % (UICPATH, RCCPATH))

FILEPATH = os.path.realpath(os.path.dirname(sys.argv[0]))

UIFILE = "dxf2gcode.ui"
PYFILEver = "dxf2gcode_ui%s.py" % pyQtVer

RCFILE = "dxf2gcode_images.qrc"
RCFILEver = "dxf2gcode_images%s.qrc" % pyQtVer

RCPYFILEver = "dxf2gcode_images%s_rc.py" % pyQtVer

ui_data = ""
with open(os.path.join(FILEPATH,UIFILE), "r") as myfile:
    ui_data = myfile.read().replace(RCFILE, RCFILEver)

fd, tmp_ui_filename = tempfile.mkstemp()
try:
    os.write(fd, bytes(ui_data, 'UTF-8'))
    os.close(fd)

    OPTIONS = "-o"

    cmd1 = [UICPATH, tmp_ui_filename, OPTIONS, os.path.join(FILEPATH,PYFILEver)]
    cmd2 = [RCCPATH, OPTIONS, os.path.join(FILEPATH,RCPYFILEver),os.path.join(FILEPATH,RCFILE)]

    print(" ".join(cmd1))
    subprocess.check_call(cmd1)

    print(" ".join(cmd2))
    subprocess.check_call(cmd2)

finally:
    os.remove(tmp_ui_filename)

print("Please consider to not commit any auto-generated files.")
print("\nREADY")

#!/bin/bash
################################################################################
#
# DXF2GCODE Installation Script for Linux V1.0
#
# This script creates a virtual environment and installs dxf2gcode
# Usage: bash install.sh
#
# by Daniel Luginbühl 2026
#
################################################################################

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Configuration
VENV_DIR="$HOME/.venv/dxf2gcode"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASHRC="$HOME/.bashrc"
TARGET_DIR="$HOME/dxf2gcode"

echo -e "${YELLOW}Step 3b: Copying source tree to $TARGET_DIR...${NC}"

# Remove old copy if exists
if [ -d "$TARGET_DIR" ]; then
    echo -e "${YELLOW}Old directory exists. Removing...${NC}"
    rm -rf "$TARGET_DIR"
fi

if [ -d "$TARGET_DIR" ]; then
    rm -rf "$TARGET_DIR"
fi
mkdir -p "$TARGET_DIR"

cp -r "$SCRIPT_DIR"/* "$TARGET_DIR"/

echo -e "${GREEN}✓ Source copied to $TARGET_DIR${NC}\n"

echo -e "${GREEN}================================${NC}"
echo -e "${GREEN}DXF2GCODE Installation${NC}"
echo -e "${GREEN}================================${NC}\n"

# Step 1: Check Python version
echo -e "${YELLOW}Step 1: Checking Python version...${NC}"
PYTHON_VERSION=$(python3 --version 2>&1 | grep -oP '\d+\.\d+')
REQUIRED_VERSION="3.10"

if (( $(echo "$PYTHON_VERSION < $REQUIRED_VERSION" | bc -l) )); then
    echo -e "${RED}Error: Python 3.10+ required, but you have Python $PYTHON_VERSION${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Python $PYTHON_VERSION found${NC}\n"

# Step 2: Create virtual environment
echo -e "${YELLOW}Step 2: Creating virtual environment at $VENV_DIR...${NC}"
if [ -d "$VENV_DIR" ]; then
    echo -e "${YELLOW}Virtual environment already exists. Removing old one...${NC}"
    rm -rf "$VENV_DIR"
fi

python3 -m venv "$VENV_DIR"
echo -e "${GREEN}✓ Virtual environment created${NC}\n"

# Step 3: Upgrade pip
echo -e "${YELLOW}Step 3: Upgrading pip, setuptools, wheel...${NC}"
"$VENV_DIR/bin/pip" install --upgrade pip setuptools wheel -q
echo -e "${GREEN}✓ Pip upgraded${NC}\n"

# Step 4: Install dxf2gcode
echo -e "${YELLOW}Step 4: Installing dxf2gcode and dependencies...${NC}"
cd "$SCRIPT_DIR"
"$VENV_DIR/bin/pip" install . -q
echo -e "${GREEN}✓ dxf2gcode installed${NC}\n"

# Step 4b: Create a small wrapper script in the venv bin directory so the command
# points to the checked-out source tree (useful during development).
WRAPPER="$VENV_DIR/bin/dxf2gcode"
echo -e "${YELLOW}Creating wrapper script at $WRAPPER...${NC}"

cat > "$WRAPPER" <<PY
#!/bin/sh
TARGET_DIR="$TARGET_DIR"
exec "$VENV_DIR/bin/python" "\$TARGET_DIR/dxf2gcode.py" "\$@"
PY

chmod +x "$WRAPPER"
echo -e "${GREEN}✓ Wrapper created${NC}\n"

# Step 5: Create alias in .bashrc
echo -e "${YELLOW}Step 5: Adding command alias to .bashrc...${NC}"
ALIAS_CMD="alias dxf2gcode='$VENV_DIR/bin/dxf2gcode'"

if grep -q "alias dxf2gcode=" "$BASHRC" 2>/dev/null; then
    echo -e "${YELLOW}Alias already exists in .bashrc. Updating...${NC}"
    # Remove old alias and add new one
    sed -i '/alias dxf2gcode=/d' "$BASHRC"
fi

echo "" >> "$BASHRC"
echo "# DXF2GCODE Command Alias" >> "$BASHRC"
echo "$ALIAS_CMD" >> "$BASHRC"
echo -e "${GREEN}✓ Alias added to .bashrc${NC}\n"

# Step 6: Clean up build artifacts
echo -e "${YELLOW}Step 6: Cleaning up build artifacts...${NC}"
rm -rf "$SCRIPT_DIR/build"
rm -rf "$SCRIPT_DIR/dist"
rm -rf "$SCRIPT_DIR/dxf2gcode.egg-info"
echo -e "${GREEN}✓ Build artifacts cleaned${NC}\n"

# Step 7: Summary
echo -e "${GREEN}================================${NC}"
echo -e "${GREEN}Installation Complete!${NC}"
echo -e "${GREEN}================================${NC}\n"

#echo -e "${YELLOW}To activate the alias, run:${NC}"
#echo -e "  ${GREEN}source ~/.bashrc${NC}\n"
mkdir -p "$HOME/.local/bin"
ln -sf "$VENV_DIR/bin/dxf2gcode" "$HOME/.local/bin/dxf2gcode"

echo -e "${YELLOW}Then you can start dxf2gcode with:${NC}"
echo -e "  ${GREEN}dxf2gcode${NC}\n"

echo -e "${YELLOW}Or run directly:${NC}"
echo -e "  ${GREEN}$VENV_DIR/bin/dxf2gcode${NC}\n"

echo -e "${YELLOW}To uninstall later:${NC}"
echo -e "  ${GREEN}rm -rf $VENV_DIR${NC}"
echo -e "  ${GREEN}# Remove alias from ~/.bashrc manually${NC}\n"

echo -e "${GREEN}Enjoy!${NC}"
